$(function(){

    const chart = function(){

        setTimeout(function(){

            $('#chart li:first').animate({marginTop:'-30px'},400,
                function(){
                    $(this).detach().appendTo('ul#chart').removeAttr('style');
                });
                chart();
        },3000);

    };

    chart();

});